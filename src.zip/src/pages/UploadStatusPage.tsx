import { Layout } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { AlertCircle, Check, Clock, Download, FileText, RefreshCw, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Resume } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";
import { getDownloadUrl } from "@/config/api";
import { formatRelativeDate } from "@/lib/utils";
import { useResumes } from "@/contexts/ResumeContext";
import { useToast } from "@/components/ui/use-toast";

const UploadStatusPage = () => {
  const { isAuthenticated, userType } = useAuth();
  const navigate = useNavigate();
  const { resumes, isLoading, loadUserResumes } = useResumes();
  const [error, setError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (!isAuthenticated || userType !== "applicant") {
      navigate("/user-login");
    }
  }, [isAuthenticated, userType, navigate]);

  // Function to refresh resumes with loading state
  const refreshResumes = useCallback(async () => {
    setIsRefreshing(true);
    setError(null);
    try {
      await loadUserResumes();
      // Toast only when manually refreshed
      if (isRefreshing) {
        toast({
          title: "Refreshed",
          description: "Your resume status has been updated",
        });
      }
    } catch (err) {
      console.error("Failed to refresh resumes:", err);
      setError("Failed to load your resumes. Please try again.");
    } finally {
      setIsRefreshing(false);
    }
  }, [loadUserResumes, isRefreshing, toast]);

  // Initial load
  useEffect(() => {
    refreshResumes();
  }, [refreshResumes]);

  // Polling for updates every 30 seconds
  useEffect(() => {
    const intervalId = setInterval(() => {
      loadUserResumes().catch(error => {
        console.error("Background refresh failed:", error);
      });
    }, 30000); // 30 seconds

    return () => clearInterval(intervalId);
  }, [loadUserResumes]);

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "reviewed":
        return <Check className="h-5 w-5 text-green-500" />;
      case "pending":
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case "rejected":
        return <X className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusText = (status?: string) => {
    switch (status) {
      case "reviewed":
        return "Reviewed";
      case "pending":
        return "Under Review";
      case "rejected":
        return "Not a Match";
      default:
        return "Processing";
    }
  };

  const downloadResume = (resume: Resume) => {
    if (resume.downloadUrl) {
      window.open(getDownloadUrl(resume.downloadUrl), "_blank");
    }
  };

  return (
    <Layout>
      <div className="py-8 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold mb-2 text-center text-white">My Resume Status</h1>
          <p className="text-center text-gray-300 mb-8">
            Track the status of your resume submissions
          </p>
        </motion.div>

        <motion.div
          className="mb-8 flex justify-center gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Button
            onClick={() => navigate("/upload")}
            className="bg-gradient-to-r from-purple-500 to-purple-700 hover:opacity-90 gap-2"
          >
            <Upload className="h-4 w-4" /> Upload New Resume
          </Button>
          
          <Button
            onClick={refreshResumes}
            disabled={isLoading || isRefreshing}
            variant="outline"
            className="border-white/20 hover:bg-white/10 text-white gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} /> 
            Refresh
          </Button>
        </motion.div>

        {(isLoading && !isRefreshing) ? (
          <div className="space-y-4">
            {[1, 2, 3].map((_, index) => (
              <Card key={index} className="backdrop-blur-sm bg-white/5 border-white/10">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-6 w-48 bg-white/10" />
                    <Skeleton className="h-6 w-24 bg-white/10" />
                  </div>
                  <Skeleton className="h-4 w-32 bg-white/10 mt-2" />
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-40 bg-white/10" />
                    <Skeleton className="h-8 w-24 bg-white/10" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-4 bg-red-500/20 border border-red-500/30 rounded-lg text-center"
          >
            <AlertCircle className="h-8 w-8 text-red-400 mx-auto mb-2" />
            <p className="text-white">{error}</p>
            <Button 
              variant="outline" 
              className="mt-4 border-white/20 hover:bg-white/10"
              onClick={refreshResumes}
            >
              Try Again
            </Button>
          </motion.div>
        ) : resumes.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 bg-white/5 border border-white/10 rounded-lg text-center"
          >
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-2" />
            <h3 className="text-lg font-medium text-white mb-2">No Resumes Found</h3>
            <p className="text-gray-400 mb-4">
              You haven't uploaded any resumes yet. Upload a resume to get started.
            </p>
            <Button 
              onClick={() => navigate("/upload")} 
              className="bg-gradient-to-r from-purple-500 to-purple-700 hover:opacity-90"
            >
              Upload Your First Resume
            </Button>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {resumes.map((resume, index) => (
              <motion.div
                key={resume.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.1 * (index + 1) }}
                className={isRefreshing ? 'opacity-50 transition-opacity duration-300' : ''}
              >
                <Card className="backdrop-blur-sm bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-300">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-purple-400" />
                        <CardTitle className="text-white">{resume.originalName || resume.filename}</CardTitle>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/5">
                        {getStatusIcon(resume.status)}
                        <span className="text-sm font-medium">
                          {getStatusText(resume.status)}
                        </span>
                      </div>
                    </div>
                    <CardDescription className="text-gray-400">
                      Uploaded {formatRelativeDate(resume.uploadDate)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-300">
                          {resume.status === "pending" ? (
                            "Your resume is being processed"
                          ) : (
                            <>
                              Match Score: 
                              <span className={`ml-2 font-bold ${
                                (resume.matchScore || 0) > 70 ? "text-green-400" :
                                (resume.matchScore || 0) > 50 ? "text-yellow-400" : "text-red-400"
                              }`}>
                                {resume.matchScore !== null ? `${resume.matchScore}%` : 'N/A'}
                              </span>
                            </>
                          )}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs border-white/20 hover:bg-white/10"
                          onClick={() => downloadResume(resume)}
                        >
                          <Download className="h-3 w-3 mr-1" /> Download
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs border-white/20 hover:bg-white/10"
                          onClick={() => navigate(`/resume/${resume.id}`)}
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default UploadStatusPage;
